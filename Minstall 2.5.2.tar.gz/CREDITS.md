General
=======

**Zsolt Ero:**

 + Helped fix countless bugs, wrote a host manager and provided many good suggestions.

Functions
=========

**extra/install-phpmyadmin:**

 + http://www.legroom.net/2010/05/06/bash-random-password-generator/

**libraries/external/read_ini.sh:**

 + http://www.github.com/rudimeier/bash_ini_parser/

**libraries/platform/check.debian.sh:**

 + http://www.servercobra.com/bash-check-if-package-is-installed/

**libraries/detect.sh:**

 + http://www.doxer.org/learn-linux/linux-shell-centos-debian-ostype/

**libraries/message.sh:**

 + http://www.linuxjournal.com/content/asking-yesno-question-bash-script/

**libraries/question.sh:**

 + http://www.linuxjournal.com/content/asking-yesno-question-bash-script/
