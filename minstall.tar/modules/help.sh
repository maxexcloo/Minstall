#!/bin/bash
# Help: General Help Information

# Print Help
cat README
