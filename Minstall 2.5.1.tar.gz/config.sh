#!/bin/bash
# Minstall Default Variable Definitions

# Default Config File
CONFIGFILE=config.ini

# Default Distribution
DISTRIBUTION=none

# Library Path
LIBRARYPATH=libraries

# Default Module
MODULE=none

# Module Path
MODULEPATH=modules

# Disable Unattended Mode
UNATTENDED=0
