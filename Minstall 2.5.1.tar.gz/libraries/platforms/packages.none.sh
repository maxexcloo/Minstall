#!/bin/bash
# Functions For Handling Package Management

# Clean Package Cache
function package_clean() {}

# Clean Package List
function package_clean_list() {}

# Install Package(s)
function package_install() {}

# Uninstall Package(s)
function package_uninstall() {}

# Update Package List
function package_update() {}

# Upgrade Packages
function package_upgrade() {}

# Add Repository
function repo_add() {}

# Add Repository Key
function repo_key() {}
