#!/bin/bash
# Functions For Checking Package/Repository Installation Status

# Check If Package Installed
function check_package() {}

# Check If Package Not Installed
function check_package_ni() {}

# Check If Repository Installed
function check_repository() {}

# Check If Repository Not Installed
function check_repository_ni() {}
