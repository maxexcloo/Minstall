#!/bin/bash
# Minstall Default Config/Variable Definitions

# Default Distribution
DISTRIBUTION=none

# Default Module
MODULE=none

# Libraries Path
LIBRARYPATH=libraries

# Module Path
MODULEPATH=modules

# Disable Unattended Mode
UNATTENDED=0

# Default Unattended Config File
CONFIGFILE=config.ini
